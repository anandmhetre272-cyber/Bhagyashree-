# Keep this file even if minification is off, it is referenced by build.gradle.kts.
-dontwarn org.jetbrains.annotations.**
