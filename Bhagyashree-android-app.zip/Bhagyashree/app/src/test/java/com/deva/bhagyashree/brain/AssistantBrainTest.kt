package com.deva.bhagyashree.brain

import com.deva.bhagyashree.data.Task
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class AssistantBrainTest {

    private val now: Long = Calendar.getInstance().apply {
        set(Calendar.YEAR, 2026)
        set(Calendar.MONTH, Calendar.JANUARY)
        set(Calendar.DAY_OF_MONTH, 5)
        set(Calendar.HOUR_OF_DAY, 9)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    @Test
    fun addTaskWithTimeProducesActionAndCleanTitle() {
        val reply = AssistantBrain.respond("add task pay the electricity bill at 6 pm", emptyList(), now)

        assertEquals(1, reply.actions.size)
        val action = reply.actions.first() as Action.AddTask
        assertEquals("Pay the electricity bill", action.title)
        assertTrue(action.triggerAtMillis != null)
        assertTrue(action.timeLabel != null)
    }

    @Test
    fun addTaskWithoutTimeHasNoAlarm() {
        val reply = AssistantBrain.respond("remind me to call amma", emptyList(), now)

        val action = reply.actions.first() as Action.AddTask
        assertEquals("Call amma", action.title)
        assertEquals(null, action.triggerAtMillis)
    }

    @Test
    fun listSummaryNumbersTheItems() {
        val tasks = listOf(
            Task(1L, "Pay bill"),
            Task(2L, "Call amma", done = true)
        )
        val reply = AssistantBrain.respond("what is on my list", tasks, now)

        assertTrue(reply.text.contains("Pay bill"))
        assertTrue(reply.text.contains("Call amma"))
        assertTrue(reply.actions.isEmpty())
    }

    @Test
    fun doneCommandTargetsTheRightIndex() {
        val tasks = listOf(Task(1L, "First"), Task(2L, "Second"))
        val reply = AssistantBrain.respond("done two", tasks, now)

        assertEquals(Action.CompleteTask(1), reply.actions.first())
    }

    @Test
    fun planMentionsTheDayAndTheBlocks() {
        val reply = AssistantBrain.respond("plan my day", listOf(Task(1L, "Pay bill")), now)

        assertTrue(reply.text.contains("Pay bill"))
        assertTrue(reply.text.contains("Suggested blocks"))
    }

    @Test
    fun unknownQuestionIsHandedToTheAi() {
        val reply = AssistantBrain.respond("why is the sky blue", emptyList(), now)

        assertTrue(reply.needsAi)
    }

    @Test
    fun inTwentyMinutesIsParsed() {
        val parsed = TimeParser.parse("stretch in 20 minutes", now)

        assertEquals(now + 20 * 60_000L, parsed?.triggerAtMillis)
    }

    @Test
    fun hindiAddCommandIsUnderstood() {
        val reply = AssistantBrain.respond("जोड़ो दूध लाना छह बजे", emptyList(), now)

        val action = reply.actions.first() as Action.AddTask
        assertEquals("दूध लाना", action.title)
        assertTrue(action.triggerAtMillis != null)
        assertEquals(Language.HINDI, reply.language)
    }

    @Test
    fun marathiListIsAnsweredInMarathi() {
        val reply = AssistantBrain.respond("माझी यादी", listOf(Task(1L, "दूध आणायचं")), now)

        assertEquals(Language.MARATHI, reply.language)
        assertTrue(reply.text.contains("दूध आणायचं"))
    }

    @Test
    fun wakeWordIsStrippedFromTheCommand() {
        assertTrue(Wake.contains("भाग्या दूध जोडा"))
        assertEquals("दूध जोडा", Wake.strip("भाग्या दूध जोडा"))
    }

    @Test
    fun hindiMorningTimeStaysInTheMorning() {
        val parsed = TimeParser.parse("सुबह 7 बजे", now)
        val hour = Calendar.getInstance().apply {
            timeInMillis = parsed!!.triggerAtMillis
        }.get(Calendar.HOUR_OF_DAY)

        assertEquals(7, hour)
    }

    @Test
    fun marathiTimeWithTomorrowIsParsed() {
        val parsed = TimeParser.parse("उद्या सकाळी 8 वाजता", now)

        assertTrue(parsed != null)
        assertTrue(parsed!!.triggerAtMillis > now)
    }
}
