package com.deva.bhagyashree.brain

import java.util.Locale

/** The three languages Bhagya speaks. */
enum class Language(val tag: String, val label: String, val locale: Locale) {
    ENGLISH("en-IN", "English", Locale("en", "IN")),
    HINDI("hi-IN", "हिंदी", Locale("hi", "IN")),
    MARATHI("mr-IN", "मराठी", Locale("mr", "IN"));

    companion object {

        val ALL: List<Language> = listOf(ENGLISH, HINDI, MARATHI)

        fun fromTag(tag: String?): Language = ALL.firstOrNull { it.tag == tag } ?: ENGLISH

        private val marathiMarkers = listOf(
            "आहे", "आहेत", "करा", "करून", "मला", "माझ", "उद्या", "सकाळ", "वाजता",
            "काढ", "दाखव", "नाही", "झालं", "आणि", "सांग", "लिहून", "आठवण", "यादी", "प्लॅन"
        )
        private val hindiMarkers = listOf(
            "है", "हैं", "करो", "करना", "मुझे", "मेरा", "मेरी", "कल", "सुबह", "बजे",
            "हटाओ", "दिखाओ", "नहीं", "हो गया", "और", "लिख", "याद", "सूची", "तारीख", "समय"
        )
        private val marathiRoman = listOf(
            "ahe", "ahet", "kara", "karun", "mala", "majha", "majhi", "udya", "sakal",
            "vajta", "kadha", "dakhav", "nahi", "zala", "sanga", "lihun", "aathvan", "yadi"
        )
        private val hindiRoman = listOf(
            "hai", "karo", "karna", "mujhe", "mera", "meri", "kal", "subah", "baje",
            "hatao", "dikhao", "nahi", "likh", "yaad", "suchi", "tarikh", "samay", "madad"
        )

        /**
         * A lightweight guess, not a full language identifier. Devanagari script decides
         * Hindi vs Marathi by which marker words appear; romanised input is scored the same way.
         */
        fun detect(text: String): Language {
            val lower = text.lowercase(Locale.US)
            val hasDevanagari = text.any { it.code in 0x0900..0x097F }

            if (hasDevanagari) {
                val marathi = marathiMarkers.count { lower.contains(it) }
                val hindi = hindiMarkers.count { lower.contains(it) }
                return if (marathi > hindi) MARATHI else HINDI
            }

            val marathi = marathiRoman.count { lower.contains(it) }
            val hindi = hindiRoman.count { lower.contains(it) }
            return when {
                marathi > hindi && marathi > 0 -> MARATHI
                hindi > 0 -> HINDI
                else -> ENGLISH
            }
        }
    }
}
