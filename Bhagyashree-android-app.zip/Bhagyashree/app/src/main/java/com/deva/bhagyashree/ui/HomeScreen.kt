package com.deva.bhagyashree.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.deva.bhagyashree.brain.Language
import com.deva.bhagyashree.data.Task
import com.deva.bhagyashree.ui.theme.Space

@Composable
fun HomeScreen(viewModel: AssistantViewModel) {
    var draft by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.startListening() else viewModel.onMicPermissionDenied()
    }

    LaunchedEffect(viewModel.messages.size) {
        if (viewModel.messages.isNotEmpty()) {
            listState.animateScrollToItem(viewModel.messages.lastIndex)
        }
    }

    FuturisticBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {

            Header(
                listening = viewModel.listening,
                thinking = viewModel.thinking,
                onSettings = { showSettings = true }
            )

            LanguageRow(
                selected = viewModel.languageTag,
                onSelect = { viewModel.setLanguage(it) }
            )

            Spacer(Modifier.height(10.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(viewModel.messages, key = { it.id }) { message ->
                    ChatBubble(message)
                }
                if (viewModel.thinking) {
                    item { ThinkingRow() }
                }
            }

            if (viewModel.tasks.isNotEmpty()) {
                TaskRail(tasks = viewModel.tasks, onToggle = { viewModel.toggleDone(it) })
            }

            Composer(
                draft = draft,
                onDraftChange = { draft = it },
                listening = viewModel.listening,
                partial = viewModel.partialText,
                handsFree = viewModel.handsFree,
                busy = viewModel.thinking,
                onHandsFree = { viewModel.setHandsFree(it) },
                onSend = {
                    val text = draft
                    draft = ""
                    viewModel.send(text)
                },
                onMic = {
                    if (viewModel.listening) {
                        viewModel.stopListening()
                    } else {
                        val granted = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) viewModel.startListening()
                        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            )
        }
    }

    if (showSettings) {
        SettingsDialog(
            initialKey = viewModel.apiKey(),
            initialModel = viewModel.model(),
            initialBase = viewModel.baseUrl(),
            pitch = viewModel.pitch,
            onPitchChange = { viewModel.setPitch(it) },
            onDismiss = { showSettings = false },
            onSave = { key, model, base ->
                viewModel.saveAiSettings(key, model, base)
                showSettings = false
            }
        )
    }
}

@Composable
private fun Header(listening: Boolean, thinking: Boolean, onSettings: () -> Unit) {
    val status = when {
        listening -> "LISTENING"
        thinking -> "THINKING"
        else -> "NEURAL CORE ONLINE"
    }
    val dot = when {
        listening -> Space.Teal
        thinking -> Space.Magenta
        else -> Space.Cyan
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = "BHAGYASHREE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = 5.sp,
                color = Space.Teal
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(6.dp)
                        .background(dot, CircleShape)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = status,
                    style = MaterialTheme.typography.labelSmall,
                    letterSpacing = 2.sp,
                    color = Space.Muted
                )
            }
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = Space.Muted)
        }
    }
}

@Composable
private fun LanguageRow(selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        LanguagePill("Auto", selected == "auto") { onSelect("auto") }
        Language.ALL.forEach { language ->
            LanguagePill(language.label, selected == language.tag) { onSelect(language.tag) }
        }
    }
}

@Composable
private fun LanguagePill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) Space.Teal.copy(alpha = 0.16f) else Color.Transparent,
        contentColor = if (selected) Space.Teal else Space.Muted,
        shape = RoundedCornerShape(percent = 50),
        border = BorderStroke(1.dp, if (selected) Space.Teal.copy(alpha = 0.6f) else Space.Line),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    val fromUser = message.fromUser
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (fromUser) Space.Teal.copy(alpha = 0.13f) else Space.Panel.copy(alpha = 0.85f),
            contentColor = if (fromUser) Space.Teal else Space.Text,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (fromUser) 18.dp else 4.dp,
                bottomEnd = if (fromUser) 4.dp else 18.dp
            ),
            border = BorderStroke(
                1.dp,
                if (fromUser) Space.Teal.copy(alpha = 0.40f) else Space.Violet.copy(alpha = 0.35f)
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@Composable
private fun ThinkingRow() {
    Text(
        text = "• • •",
        style = MaterialTheme.typography.bodyLarge,
        letterSpacing = 4.sp,
        color = Space.Cyan
    )
}

@Composable
private fun TaskRail(tasks: List<Task>, onToggle: (Task) -> Unit) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tasks) { task ->
            val accent = if (task.done) Space.Muted else Space.Cyan
            Surface(
                color = Space.Panel.copy(alpha = 0.7f),
                contentColor = accent,
                shape = RoundedCornerShape(percent = 50),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
                modifier = Modifier.clickable { onToggle(task) }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(6.dp)
                            .background(accent, CircleShape)
                    )
                    Spacer(Modifier.width(7.dp))
                    val time = task.timeLabel?.let { " · $it" }.orEmpty()
                    Text(
                        text = task.title + time,
                        maxLines = 1,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun Composer(
    draft: String,
    onDraftChange: (String) -> Unit,
    listening: Boolean,
    partial: String,
    handsFree: Boolean,
    busy: Boolean,
    onHandsFree: (Boolean) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VoiceOrb(listening = listening, onClick = onMic, size = 62.dp)

            Surface(
                color = Space.Panel.copy(alpha = 0.9f),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, if (listening) Space.Teal.copy(alpha = 0.6f) else Space.Line),
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    value = if (listening && partial.isNotBlank()) partial else draft,
                    onValueChange = onDraftChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(
                            text = if (listening) "Listening..." else "Type, or tap the orb",
                            color = Space.Muted
                        )
                    },
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        cursorColor = Space.Teal,
                        focusedTextColor = Space.Text,
                        unfocusedTextColor = Space.Text
                    )
                )
            }

            IconButton(onClick = onSend, enabled = draft.isNotBlank() && !busy) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (draft.isNotBlank()) Space.Teal else Space.Muted
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = if (handsFree) Space.Violet.copy(alpha = 0.18f) else Color.Transparent,
                contentColor = if (handsFree) Space.Violet else Space.Muted,
                shape = RoundedCornerShape(percent = 50),
                border = BorderStroke(1.dp, if (handsFree) Space.Violet.copy(alpha = 0.55f) else Space.Line),
                modifier = Modifier.clickable { onHandsFree(!handsFree) }
            ) {
                Text(
                    text = if (handsFree) "Wake word on · Bhagya" else "Wake word off",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                text = "भाग्या · भाग्यश्री",
                style = MaterialTheme.typography.labelSmall,
                color = Space.Muted
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    initialKey: String,
    initialModel: String,
    initialBase: String,
    pitch: Float,
    onPitchChange: (Float) -> Unit,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var key by remember { mutableStateOf(initialKey) }
    var model by remember { mutableStateOf(initialModel) }
    var base by remember { mutableStateOf(initialBase) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bhagya settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Voice pitch ${"%.2f".format(pitch)}",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = pitch,
                    onValueChange = onPitchChange,
                    valueRange = 0.8f..1.6f
                )
                Text(
                    text = "Higher is younger. 1.20 to 1.30 sounds like a teenage girl.",
                    style = MaterialTheme.typography.bodySmall
                )

                Text(
                    text = "AI key (optional)",
                    style = MaterialTheme.typography.labelLarge
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text("Model") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = base,
                    onValueChange = { base = it },
                    label = { Text("Base URL") },
                    singleLine = true
                )
                Text(
                    text = "Stored only on this phone. Any OpenAI compatible service works.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(key, model, base) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
