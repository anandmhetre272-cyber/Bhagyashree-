package com.deva.bhagyashree.llm

import android.content.Context
import com.deva.bhagyashree.brain.Language
import com.deva.bhagyashree.data.Task
import com.deva.bhagyashree.data.TaskStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Optional AI answers. Works with any OpenAI compatible endpoint (OpenAI, Groq, OpenRouter,
 * a local server) because it only uses the /chat/completions shape.
 *
 * The key lives in the app's private SharedPreferences on the phone. Fine for a personal build.
 * If you ever ship this app, move the call behind your own backend.
 */
class LlmClient(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(TaskStore.PREFS_NAME, Context.MODE_PRIVATE)

    val hasKey: Boolean get() = apiKey().isNotBlank()

    fun apiKey(): String = prefs.getString(KEY_API, "").orEmpty()

    fun model(): String = prefs.getString(KEY_MODEL, DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }

    fun baseUrl(): String = prefs.getString(KEY_BASE, DEFAULT_BASE).orEmpty().ifBlank { DEFAULT_BASE }

    fun saveSettings(apiKey: String, model: String, baseUrl: String) {
        prefs.edit()
            .putString(KEY_API, apiKey.trim())
            .putString(KEY_MODEL, model.trim().ifBlank { DEFAULT_MODEL })
            .putString(KEY_BASE, baseUrl.trim().ifBlank { DEFAULT_BASE })
            .apply()
    }

    suspend fun ask(question: String, tasks: List<Task>, language: Language): String =
        withContext(Dispatchers.IO) {
            val key = apiKey()
            if (key.isBlank()) return@withContext NO_KEY

            var connection: HttpURLConnection? = null
            try {
                val url = URL(baseUrl().trimEnd('/') + "/chat/completions")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }

                val body = JSONObject().apply {
                    put("model", model())
                    put("max_tokens", 320)
                    put("temperature", 0.5)
                    put("messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", systemPrompt(tasks, language)))
                        put(JSONObject().put("role", "user").put("content", question))
                    })
                }

                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                if (code !in 200..299) {
                    return@withContext "The AI service answered with error $code. Check the key, the model name and the base URL in Settings."
                }

                val content = JSONObject(response)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()
                    .orEmpty()

                if (content.isEmpty()) FALLBACK else content
            } catch (e: Exception) {
                "I could not reach the AI service. Check your internet connection and try again."
            } finally {
                connection?.disconnect()
            }
        }

    private fun systemPrompt(tasks: List<Task>, language: Language): String {
        val today = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
        val list = if (tasks.isEmpty()) {
            "The user's task list is empty."
        } else {
            "The user's task list right now: " + tasks.joinToString("; ") { task ->
                val state = if (task.done) "done" else "open"
                val time = task.timeLabel?.let { " at $it" }.orEmpty()
                "${task.title}$time ($state)"
            } + "."
        }
        val replyLanguage = when (language) {
            Language.ENGLISH -> "Reply in simple English."
            Language.HINDI -> "Reply in simple Hindi, in Devanagari script, the way a young Indian girl speaks."
            Language.MARATHI -> "Reply in simple Marathi, in Devanagari script, the way a young Indian girl speaks."
        }
        return "You are Bhagya, a bright teenage Indian personal assistant. " +
            "Today is $today. $replyLanguage " +
            "Answer in at most three short sentences because your reply is read aloud. " +
            "No markdown, no bullet points, no emojis, no lists, no English words inside Hindi or Marathi sentences unless there is no alternative. " +
            "If the user asks you to add, complete or delete a task, tell them to say it as a command. $list"
    }

    companion object {
        const val DEFAULT_MODEL = "gpt-4o-mini"
        const val DEFAULT_BASE = "https://api.openai.com/v1"
        const val NO_KEY = "I do not have an AI key yet. Open Settings and paste one, or ask me to add tasks, " +
            "show your list, or plan your day, which I can do offline."
        const val FALLBACK = "I could not think of a good answer for that. Try asking in a different way."

        private const val KEY_API = "llm_api_key"
        private const val KEY_MODEL = "llm_model"
        private const val KEY_BASE = "llm_base_url"
    }
}
