package com.deva.bhagyashree.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import com.deva.bhagyashree.brain.Language
import java.util.Locale

/**
 * Bhagya's voice. She is meant to sound like a bright teenage Indian girl, so the pitch sits
 * above neutral and the rate is a touch quick. Both are adjustable from Settings.
 *
 * The phone's TTS engine decides the actual timbre. If a Hindi or Marathi voice is not installed,
 * Android falls back to English, so [supports] is exposed for the UI to warn about it.
 */
class Speaker(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingText: String? = null
    private var pendingLanguage: Language = Language.ENGLISH
    private var currentLanguage: Language? = null
    private var counter = 0

    var pitch: Float = 1.22f
    var rate: Float = 1.02f
    var isMuted: Boolean = false

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) onEngineReady()
        }
    }

    private fun onEngineReady() {
        val engine = tts ?: return
        engine.setSpeechRate(rate)
        engine.setPitch(pitch)
        ready = true
        val queued = pendingText
        val queuedLanguage = pendingLanguage
        pendingText = null
        if (queued != null) speak(queued, queuedLanguage)
    }

    fun speak(text: String, language: Language) {
        val clean = sanitize(text)
        if (clean.isEmpty() || isMuted) return
        val engine = tts
        if (engine == null || !ready) {
            pendingText = clean
            pendingLanguage = language
            init()
            return
        }
        applyLanguage(engine, language)
        engine.setPitch(pitch)
        engine.setSpeechRate(rate)
        counter += 1
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "bhagya-$counter")
    }

    fun supports(language: Language): Boolean {
        val engine = tts ?: return false
        return engine.isLanguageAvailable(language.locale) >= TextToSpeech.LANG_AVAILABLE
    }

    fun applyVoiceSettings(newPitch: Float, newRate: Float) {
        pitch = newPitch
        rate = newRate
        tts?.setPitch(newPitch)
        tts?.setSpeechRate(newRate)
    }

    fun stop() {
        tts?.stop()
        pendingText = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        currentLanguage = null
    }

    private fun applyLanguage(engine: TextToSpeech, language: Language) {
        if (currentLanguage == language) return
        val result = engine.setLanguage(language.locale)
        currentLanguage = if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            engine.language = Locale("en", "IN")
            Language.ENGLISH
        } else {
            language
        }
    }

    /** Strips characters the voice would read out as noise. */
    private fun sanitize(text: String): String {
        return text
            .replace(Regex("[*_`#>\\[\\]]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
