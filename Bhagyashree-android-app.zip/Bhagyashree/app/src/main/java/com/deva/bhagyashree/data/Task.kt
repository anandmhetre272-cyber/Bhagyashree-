package com.deva.bhagyashree.data

/**
 * One item on the user's list.
 *
 * @param timeLabel   human friendly time, e.g. "Fri, 14 Nov 7:00 PM", used when speaking.
 * @param triggerAtMillis when the reminder alarm should fire, null when the task has no time.
 */
data class Task(
    val id: Long,
    val title: String,
    val timeLabel: String? = null,
    val triggerAtMillis: Long? = null,
    val done: Boolean = false
)
