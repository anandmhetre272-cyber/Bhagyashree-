package com.deva.bhagyashree.brain

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ParsedTime(val label: String, val triggerAtMillis: Long)

/**
 * Reads times from English, Hindi and Marathi speech:
 * "at 6 pm", "in 20 minutes", "tomorrow at 9",
 * "छह बजे", "सुबह 7 बजे", "उद्या सकाळी 8 वाजता", "saha vajta".
 * Pure Kotlin, no Android imports, so it is unit tested.
 */
object TimeParser {

    private val inRegexAscii = Regex("""\bin\s+(\d{1,3})\s*(minutes?|mins?|hours?|hrs?)\b""")
    private val inRegexLocal = Regex("""(\d{1,3})\s*(मिनट|मिनिट|तास|घंटे|घंटा|मिनिटांत|तासात)""")
    private val clockMarked = Regex("""(\d{1,2})(?::(\d{2}))?\s*(?:बजे|वाजता|baje|vajta)""", RegexOption.IGNORE_CASE)
    private val amPmRegex = Regex("""\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b""", RegexOption.IGNORE_CASE)
    private val atClockRegex = Regex("""\bat\s+(\d{1,2})(?::(\d{2}))?\b""", RegexOption.IGNORE_CASE)

    private val hourWords: List<Pair<String, Int>> = listOf(
        "ग्यारह" to 11, "बारह" to 12, "पाँच" to 5, "पांच" to 5, "छह" to 6, "छः" to 6,
        "सात" to 7, "आठ" to 8, "नौ" to 9, "दस" to 10, "एक" to 1, "दो" to 2,
        "तीन" to 3, "चार" to 4, "अकरा" to 11, "बारा" to 12, "दोन" to 2, "पाच" to 5,
        "सहा" to 6, "नऊ" to 9, "दहा" to 10,
        "gyarah" to 11, "barah" to 12, "paanch" to 5, "chhah" to 6, "saat" to 7,
        "aath" to 8, "nau" to 9, "das" to 10, "daha" to 10, "akra" to 11, "bara" to 12,
        "don" to 2, "saha" to 6, "teen" to 3, "char" to 4, "paach" to 5, "ek" to 1, "do" to 2
    ).sortedByDescending { it.first.length }

    private val partOfDay: List<Pair<String, Int>> = listOf(
        "morning" to 8, "सुबह" to 8, "सकाळ" to 8, "sakal" to 8,
        "afternoon" to 15, "दोपहर" to 15, "दुपार" to 15, "dupar" to 15,
        "evening" to 19, "शाम" to 19, "संध्याकाळ" to 19, "sandhyakal" to 19,
        "tonight" to 21, "night" to 21, "रात" to 21, "रात्र" to 21, "raat" to 21
    )

    private val morningWords = listOf("morning", "सुबह", "सकाळ", "sakal")
    private val tomorrowWords = listOf("tomorrow", "कल", "उद्या", "udya")

    private val stripRegex = Regex(
        """\bat\s+\d{1,2}(?::\d{2})?\s*(am|pm)?""" +
            """|\b\d{1,2}(?::\d{2})?\s*(am|pm)\b""" +
            """|\d{1,2}(?::\d{2})?\s*(बजे|वाजता|baje|vajta)""" +
            """|\bin\s+\d{1,3}\s*(minutes?|mins?|hours?|hrs?)\b""" +
            """|\d{1,3}\s*(मिनट|मिनिट|तास|घंटे|घंटा|मिनिटांत|तासात)""" +
            """|\b(today|tomorrow|tonight)\b""" +
            """|(आज|कल|उद्या|सुबह|सकाळ|दोपहर|दुपार|शाम|संध्याकाळ|रात|रात्र)""",
        RegexOption.IGNORE_CASE
    )

    fun parse(text: String, now: Long = System.currentTimeMillis()): ParsedTime? {
        var work = normalizeDigits(text.lowercase(Locale.US))
        if (hasClockMarker(work)) work = replaceHourWords(work)

        inRegexAscii.find(work)?.let { match ->
            val amount = match.groupValues[1].toIntOrNull()
            if (amount != null && amount > 0) {
                val unit = match.groupValues[2]
                val millis = if (unit.startsWith("h")) amount * 3_600_000L else amount * 60_000L
                val at = now + millis
                return ParsedTime(label(at), at)
            }
        }
        inRegexLocal.find(work)?.let { match ->
            val amount = match.groupValues[1].toIntOrNull()
            if (amount != null && amount > 0) {
                val unit = match.groupValues[2]
                val isHour = unit.startsWith("तास") || unit.startsWith("घंट")
                val millis = if (isHour) amount * 3_600_000L else amount * 60_000L
                val at = now + millis
                return ParsedTime(label(at), at)
            }
        }

        val partHour = findPartOfDay(work)
        val morning = isMorning(work)

        var hour: Int? = null
        var minute = 0

        val marked = clockMarked.find(work)
        val amPm = if (marked == null) amPmRegex.find(work) else null
        val atClock = if (marked == null && amPm == null) atClockRegex.find(work) else null
        val match = marked ?: amPm ?: atClock

        if (match != null) {
            val rawHour = match.groupValues[1].toIntOrNull()
            if (rawHour != null && rawHour in 0..23) {
                val rawMinute = match.groupValues[2].toIntOrNull() ?: 0
                minute = if (rawMinute in 0..59) rawMinute else 0
                val suffix = if (amPm != null) {
                    amPm.groupValues.getOrNull(3)?.lowercase(Locale.US).orEmpty()
                } else {
                    ""
                }
                var resolved = rawHour
                when {
                    suffix == "pm" && resolved < 12 -> resolved += 12
                    suffix == "am" && resolved == 12 -> resolved = 0
                    suffix.isEmpty() && morning && resolved == 12 -> resolved = 0
                    suffix.isEmpty() && !morning && resolved in 1..11 -> resolved += 12
                }
                hour = resolved
            }
        }

        val targetHour = hour ?: partHour ?: return null

        val calendar = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, targetHour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (isTomorrow(work)) calendar.add(Calendar.DAY_OF_YEAR, 1)
        if (calendar.timeInMillis <= now) calendar.add(Calendar.DAY_OF_YEAR, 1)

        return ParsedTime(label(calendar.timeInMillis), calendar.timeInMillis)
    }

    /** Removes the time phrase so what is left is a clean task title. */
    fun strip(text: String): String {
        var work = text
        if (hasClockMarker(work)) work = replaceHourWords(work)
        return work
            .replace(stripRegex, " ")
            .replace(Regex("""\s+"""), " ")
            .replace(Regex("""\s+([.,!?।])"""), "\$1")
            .trim()
            .trim(',', '.', ';', '-', ' ')
    }

    private fun normalizeDigits(text: String): String {
        val builder = StringBuilder(text.length)
        text.forEach { character ->
            builder.append(
                if (character in '\u0966'..'\u096F') ('0' + (character - '\u0966')) else character
            )
        }
        return builder.toString()
    }

    private fun hasClockMarker(text: String): Boolean =
        text.contains("बजे") || text.contains("वाजता") ||
            text.contains("baje") || text.contains("vajta")

    private fun replaceHourWords(text: String): String {
        var result = text
        hourWords.forEach { (word, value) ->
            result = if (word.any { it.code in 0x0900..0x097F }) {
                result.replace(word, " $value ")
            } else {
                result.replace(Regex("\\b" + Regex.escape(word) + "\\b"), " $value ")
            }
        }
        return result
    }

    private fun findPartOfDay(text: String): Int? =
        partOfDay.firstOrNull { (word, _) -> containsWord(text, word) }?.second

    private fun isMorning(text: String): Boolean =
        morningWords.any { containsWord(text, it) }

    private fun isTomorrow(text: String): Boolean =
        tomorrowWords.any { containsWord(text, it) }

    private fun containsWord(text: String, word: String): Boolean =
        if (word.any { it.code in 0x0900..0x097F }) text.contains(word)
        else Regex("(^|\\W)" + Regex.escape(word) + "(\\W|$)").containsMatchIn(text)

    private fun label(at: Long): String =
        SimpleDateFormat("EEE, d MMM h:mm a", Locale.getDefault()).format(Date(at))
}
