package com.deva.bhagyashree.brain

import com.deva.bhagyashree.data.Task
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The spoken answers that do not need an AI: the list summary and the day plan, in three languages.
 */
object RoutinePlanner {

    fun summary(language: Language, tasks: List<Task>): String {
        if (tasks.isEmpty()) return empty(language)

        val open = tasks.count { !it.done }
        val builder = StringBuilder()

        when (language) {
            Language.ENGLISH ->
                if (open == 0) builder.append("Nothing open. ")
                else builder.append("You have $open open item${if (open == 1) "" else "s"}. ")
            Language.HINDI ->
                if (open == 0) builder.append("अभी कुछ बाकी नहीं है। ")
                else builder.append("आपके पास $open काम बाकी हैं। ")
            Language.MARATHI ->
                if (open == 0) builder.append("आता काही बाकी नाही. ")
                else builder.append("तुमच्याकडे $open कामं बाकी आहेत. ")
        }

        tasks.forEachIndexed { index, task ->
            val number = index + 1
            val label = task.timeLabel
            when (language) {
                Language.ENGLISH -> {
                    val time = if (label == null) "" else " at $label"
                    val state = if (task.done) "done" else "open"
                    builder.append("$number. ${task.title}$time, $state. ")
                }
                Language.HINDI -> {
                    val time = if (label == null) "" else ", $label पर"
                    val state = if (task.done) "पूरा" else "बाकी"
                    builder.append("$number. ${task.title}$time, $state। ")
                }
                Language.MARATHI -> {
                    val time = if (label == null) "" else ", $label ला"
                    val state = if (task.done) "पूर्ण" else "बाकी"
                    builder.append("$number. ${task.title}$time, $state. ")
                }
            }
        }
        return builder.toString().trim()
    }

    fun plan(language: Language, tasks: List<Task>, now: Long): String {
        val open = tasks.filter { !it.done }
        val timed = open.filter { it.triggerAtMillis != null }.sortedBy { it.triggerAtMillis }
        val untimed = open.filter { it.triggerAtMillis == null }
        val day = SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(now))

        val builder = StringBuilder()

        when (language) {
            Language.ENGLISH -> {
                builder.append("Here is your plan for $day. ")
                if (open.isEmpty()) {
                    builder.append("Your list is empty, so start by adding the two or three things that would make today count. ")
                } else {
                    if (timed.isNotEmpty()) {
                        builder.append("Fixed items. ")
                        timed.forEach { builder.append("${it.timeLabel}, ${it.title}. ") }
                    }
                    if (untimed.isNotEmpty()) {
                        builder.append("Not scheduled yet. ")
                        untimed.forEach { builder.append("${it.title}. ") }
                    }
                }
                builder.append("Suggested blocks. Eight to ten in the morning, deep work on the hardest item, phone away. ")
                builder.append("Ten thirty, water and ten minutes outside. ")
                builder.append("Eleven to one, continue the main task or clear the unscheduled ones. ")
                builder.append("One o'clock, lunch away from the screen. ")
                builder.append("Three to five, calls and anything that needs another person. ")
                builder.append("Six, a walk or a workout. ")
                builder.append("Nine, review the day, move what is left to tomorrow, and wind down.")
            }

            Language.HINDI -> {
                builder.append("$day की योजना। ")
                if (open.isEmpty()) {
                    builder.append("लिस्ट खाली है, तो पहले दो-तीन काम जोड़िए जिनसे दिन सार्थक होगा। ")
                } else {
                    if (timed.isNotEmpty()) {
                        builder.append("तय किए हुए काम। ")
                        timed.forEach { builder.append("${it.timeLabel}, ${it.title}। ") }
                    }
                    if (untimed.isNotEmpty()) {
                        builder.append("बाकी काम। ")
                        untimed.forEach { builder.append("${it.title}। ") }
                    }
                }
                builder.append("सुझाव। सुबह आठ से दस, सबसे कठिन काम पर ध्यान, फोन दूर। ")
                builder.append("साढ़े दस, पानी और दस मिनट बाहर। ")
                builder.append("ग्यारह से एक, मुख्य काम आगे बढ़ाइए या बाकी काम निपटाइए। ")
                builder.append("एक बजे खाना, स्क्रीन से दूर। ")
                builder.append("तीन से पाँच, कॉल और वो काम जिनके लिए किसी और की ज़रूरत है। ")
                builder.append("छह बजे, थोड़ी चहलक़दमी या कसरत। ")
                builder.append("नौ बजे, दिन देखिए, बचा काम कल पर डालिए और आराम कीजिए।")
            }

            Language.MARATHI -> {
                builder.append("$day ची योजना. ")
                if (open.isEmpty()) {
                    builder.append("यादी रिकामी आहे, तर आधी दोन-तीन कामं जोडा ज्यांनी दिवस सार्थक होईल. ")
                } else {
                    if (timed.isNotEmpty()) {
                        builder.append("ठरलेली कामं. ")
                        timed.forEach { builder.append("${it.timeLabel}, ${it.title}. ") }
                    }
                    if (untimed.isNotEmpty()) {
                        builder.append("बाकी कामं. ")
                        untimed.forEach { builder.append("${it.title}. ") }
                    }
                }
                builder.append("सूचना. सकाळी आठ ते दहा, सर्वात कठीण कामावर लक्ष, फोन दूर. ")
                builder.append("साडेदहा, पाणी आणि दहा मिनिटं बाहेर. ")
                builder.append("अकरा ते एक, मुख्य काम पुढे न्या किंवा बाकी कामं संपवा. ")
                builder.append("एक वाजता जेवण, स्क्रीनपासून दूर. ")
                builder.append("तीन ते पाच, कॉल आणि दुसऱ्यांशी बोलायची कामं. ")
                builder.append("सहा वाजता, थोडी चाल किंवा व्यायाम. ")
                builder.append("नऊ वाजता, दिवस बघा, उरलेलं काम उद्यासाठी ठेवा आणि आराम करा.")
            }
        }
        return builder.toString().trim()
    }

    private fun empty(language: Language): String = when (language) {
        Language.ENGLISH -> "Your list is empty. Say add, and then tell me what to add."
        Language.HINDI -> "लिस्ट खाली है। जोड़ो कहिए और बताइए क्या जोड़ना है।"
        Language.MARATHI -> "यादी रिकामी आहे. जोडा म्हणा आणि सांगा काय जोडायचं."
    }
}
