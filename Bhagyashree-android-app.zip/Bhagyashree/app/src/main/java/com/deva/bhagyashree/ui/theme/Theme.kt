package com.deva.bhagyashree.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * "Live advanced civilisation" look: deep space navy, holographic teal and violet.
 * Always dark on purpose - this is a control deck, not a form.
 */
object Space {
    val Deep = Color(0xFF04070F)
    val Deck = Color(0xFF071426)
    val Panel = Color(0xFF0E1A2B)
    val Line = Color(0xFF1B3A5C)
    val Teal = Color(0xFF35F0C8)
    val Cyan = Color(0xFF5CE1FF)
    val Violet = Color(0xFFA56CFF)
    val Magenta = Color(0xFFFF6BD6)
    val Text = Color(0xFFE6F4FF)
    val Muted = Color(0xFF8FA8C0)
}

private val SpaceColors = darkColorScheme(
    primary = Space.Teal,
    onPrimary = Color(0xFF002019),
    primaryContainer = Color(0xFF0C3B33),
    onPrimaryContainer = Color(0xFF9BFFE8),
    secondary = Space.Violet,
    onSecondary = Color(0xFF16002E),
    tertiary = Space.Cyan,
    onTertiary = Color(0xFF001B22),
    surface = Space.Deck,
    onSurface = Space.Text,
    surfaceVariant = Space.Panel,
    onSurfaceVariant = Space.Muted,
    outline = Space.Line,
    background = Space.Deep,
    onBackground = Space.Text,
    error = Color(0xFFFF7A90)
)

@Composable
fun BhagyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SpaceColors, content = content)
}
