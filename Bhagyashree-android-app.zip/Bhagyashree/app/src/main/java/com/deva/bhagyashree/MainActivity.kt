package com.deva.bhagyashree

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.deva.bhagyashree.ui.AssistantViewModel
import com.deva.bhagyashree.ui.HomeScreen
import com.deva.bhagyashree.ui.theme.BhagyaTheme
import com.deva.bhagyashree.ui.theme.Space

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val notificationPermission = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { /* reminders simply stay silent if denied */ }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        viewModel.speaker.init()

        setContent {
            BhagyaTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Space.Deep) {
                    HomeScreen(viewModel)
                }
            }
        }
    }
}
