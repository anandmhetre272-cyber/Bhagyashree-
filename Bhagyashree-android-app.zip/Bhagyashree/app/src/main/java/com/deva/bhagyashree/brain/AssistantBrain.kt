package com.deva.bhagyashree.brain

import com.deva.bhagyashree.data.Task
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Something the assistant wants the app to do after it answers. */
sealed interface Action {
    data class AddTask(val title: String, val timeLabel: String?, val triggerAtMillis: Long?) : Action
    data class CompleteTask(val index: Int) : Action
    data class DeleteTask(val index: Int) : Action
    data object ClearDone : Action
}

data class Reply(
    val text: String,
    val actions: List<Action> = emptyList(),
    /** true when the question is beyond the offline rules and an AI answer would help. */
    val needsAi: Boolean = false,
    val language: Language = Language.ENGLISH
)

/**
 * The offline brain, in English, Hindi and Marathi. Rules first, AI only as a fallback, so the
 * app stays useful without a network or an API key. Plain Kotlin: no Android imports.
 */
object AssistantBrain {

    private val helpWords = listOf(
        "help", "madad", "मदद", "मदत", "what can you do", "क्या कर सकती", "काय करू शकते"
    )
    private val greetingRegex = Regex(
        """^(hi|hii|hey|hello|namaste|namaskar|नमस्ते|नमस्कार|yo)\b"""
    )
    private val thanksWords = listOf("thank", "thanks", "शुक्रिया", "धन्यवाद", "आभार")

    private val addPrefixes = listOf(
        "add task ", "add a task ", "add to my list ", "add to list ", "add ",
        "remind me to ", "remind me ", "remember to ", "remember ",
        "note down ", "note ", "i need to ", "i have to ",
        "टास्क जोड़ो ", "काम जोड़ो ", "जोड़ो ", "जोड़ दो ", "याद रखो ", "याद दिलाओ ",
        "लिख लो ", "नोट करो ", "याद करो ",
        "टास्क जोडा ", "काम जोडा ", "जोडा ", "आठवण करून दे ", "लक्षात ठेव ", "लिहून ठेव "
    )

    private val listWords = listOf(
        "my list", "my tasks", "show tasks", "what is on my list", "whats on my list",
        "to do list", "what do i have", "list",
        "मेरी लिस्ट", "मेरी सूची", "लिस्ट दिखाओ", "टास्क दिखाओ", "सूची दिखाओ", "लिस्ट",
        "माझी यादी", "यादी दाखव", "कामं दाखव", "लिस्ट दाखव", "यादी"
    )

    private val planWords = listOf(
        "plan my day", "plan the day", "plan today", "plan for today", "my routine", "daily routine",
        "दिन की योजना", "मेरा रूटीन", "मेरी दिनचर्या", "दिनचर्या", "प्लान बनाओ", "आज का प्लान",
        "दिनाची योजना", "माझं रूटीन", "माझी दिनचर्या", "आजचा प्लॅन", "प्लॅन कर"
    )

    private val clearDoneWords = listOf(
        "clear done", "clear completed", "remove finished", "delete finished",
        "पूरे हुए हटाओ", "हो गए हटाओ", "पूर्ण झालेले काढा", "झालेले काढा"
    )

    private val doneWords = listOf(
        "done", "complete", "completed", "finish", "finished",
        "पूरा कर", "पूरा हो", "हो गया", "पूर्ण कर", "पूर्ण झाल", "झालं", "झाला"
    )
    private val deleteWords = listOf(
        "delete", "remove", "drop", "cancel",
        "हटाओ", "हटा दो", "मिटाओ", "काढा", "काढून टाक", "काढून"
    )

    private val countWords = listOf(
        "how many task", "how many item", "कितने टास्क", "कितने काम", "किती काम"
    )
    private val timeWords = listOf(
        "what time", "the time", "time", "कितने बजे", "समय", "टाइम", "किती वाजले", "वेळ"
    )
    private val dateWords = listOf(
        "what is the date", "whats the date", "what day is it", "todays date", "today's date", "date",
        "आज की तारीख", "तारीख", "आजची तारीख", "आज काय दिवस"
    )

    private val numberWords: List<Pair<String, Int>> = listOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10,
        "एक" to 1, "दो" to 2, "दोन" to 2, "तीन" to 3, "चार" to 4, "पाँच" to 5, "पांच" to 5,
        "पाच" to 5, "छह" to 6, "सहा" to 6, "सात" to 7, "आठ" to 8, "नौ" to 9, "नऊ" to 9,
        "दस" to 10, "दहा" to 10
    ).sortedByDescending { it.first.length }

    fun respond(
        input: String,
        tasks: List<Task>,
        now: Long = System.currentTimeMillis(),
        forcedLanguage: Language? = null
    ): Reply {
        val text = input.trim()
        val language = forcedLanguage ?: Language.detect(text)
        if (text.isEmpty()) return Reply(Phrases.greeting(language), language = language)

        val lower = text.lowercase(Locale.US).trim().trimEnd('?', '.', '!', ',', '।').trim()
        val command = withDigits(lower)

        if (matchesAny(command, helpWords)) return Reply(Phrases.help(language), language = language)

        // Adding is checked before everything else, because "add milk to my list" also
        // contains "my list".
        val addPrefix = addPrefixes.firstOrNull { lower.startsWith(it) }
        if (addPrefix != null) {
            var body = text.substring(addPrefix.length).trim()
            body = body
                .replace(
                    Regex("""\s+(to|in|on)\s+my\s+(list|tasks?|todo|routine)$""", RegexOption.IGNORE_CASE),
                    ""
                )
                .trim()
                .trimEnd('.', ',', ';', '।')
                .trim()

            if (body.isBlank()) return Reply(Phrases.whatToAdd(language), language = language)

            val time = TimeParser.parse(body, now)
            val cleaned = TimeParser.strip(body)
            val title = (cleaned.ifBlank { body }).replaceFirstChar { it.uppercase() }
            return Reply(
                Phrases.added(language, title, time?.label),
                listOf(Action.AddTask(title, time?.label, time?.triggerAtMillis)),
                language = language
            )
        }

        if (matchesAny(command, clearDoneWords)) {
            val doneCount = tasks.count { it.done }
            return if (doneCount == 0) {
                Reply(Phrases.nothingDone(language), language = language)
            } else {
                Reply(
                    Phrases.cleared(language, doneCount),
                    listOf(Action.ClearDone),
                    language = language
                )
            }
        }

        if (matchesAny(command, planWords)) {
            return Reply(RoutinePlanner.plan(language, tasks, now), language = language)
        }

        if (matchesAny(command, listWords)) {
            return Reply(RoutinePlanner.summary(language, tasks), language = language)
        }

        if (matchesAny(command, countWords)) {
            val open = tasks.count { !it.done }
            return Reply(Phrases.count(language, open), language = language)
        }

        val number = Regex("""\d{1,2}""").find(command)?.value?.toIntOrNull()

        if (number != null && matchesAny(command, doneWords)) {
            val task = tasks.getOrNull(number - 1)
            return if (task == null) {
                Reply(Phrases.notFound(language, number.toString()), language = language)
            } else {
                Reply(
                    Phrases.done(language, task.title),
                    listOf(Action.CompleteTask(number - 1)),
                    language = language
                )
            }
        }

        if (number != null && matchesAny(command, deleteWords)) {
            val task = tasks.getOrNull(number - 1)
            return if (task == null) {
                Reply(Phrases.notFound(language, number.toString()), language = language)
            } else {
                Reply(
                    Phrases.removed(language, task.title),
                    listOf(Action.DeleteTask(number - 1)),
                    language = language
                )
            }
        }

        if (matchesAny(command, timeWords)) {
            val clock = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now))
            return Reply(Phrases.clock(language, clock), language = language)
        }

        if (matchesAny(command, dateWords)) {
            val day = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date(now))
            return Reply(Phrases.date(language, day), language = language)
        }

        if (greetingRegex.containsMatchIn(lower)) {
            return Reply(Phrases.greeting(language), language = language)
        }

        if (matchesAny(command, thanksWords)) {
            return Reply(Phrases.thanks(language), language = language)
        }

        return Reply(Phrases.fallback(language), needsAi = true, language = language)
    }

    /** Spoken commands arrive as words ("done two", "दो पूरा करो"), the rules want digits. */
    private fun withDigits(text: String): String {
        var result = text
        numberWords.forEach { (word, value) ->
            result = if (word.any { it.code in 0x0900..0x097F }) {
                result.replace(word, " $value ")
            } else {
                result.replace(Regex("\\b" + Regex.escape(word) + "\\b"), " $value ")
            }
        }
        return result
    }

    private fun matchesAny(text: String, words: List<String>): Boolean =
        words.any { containsWord(text, it) }

    private fun containsWord(text: String, word: String): Boolean =
        if (word.any { it.code in 0x0900..0x097F }) text.contains(word)
        else Regex("(^|\\W)" + Regex.escape(word) + "(\\W|$)").containsMatchIn(text)
}
