package com.deva.bhagyashree.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Dead simple persistence: the whole list is stored as a JSON string in SharedPreferences.
 * Small lists, no migrations, no database needed. Swap this class for Room later if the
 * list grows big; nothing else in the app needs to change.
 */
class TaskStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): List<Task> {
        val raw = prefs.getString(KEY_TASKS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val title = item.optString("title", "").trim()
                if (title.isEmpty()) return@mapNotNull null
                Task(
                    id = item.optLong("id", index.toLong() + 1),
                    title = title,
                    timeLabel = if (item.isNull("timeLabel")) null else item.optString("timeLabel"),
                    triggerAtMillis = if (item.isNull("triggerAt")) null else item.optLong("triggerAt"),
                    done = item.optBoolean("done", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(tasks: List<Task>) {
        val array = JSONArray()
        tasks.forEach { task ->
            array.put(JSONObject().apply {
                put("id", task.id)
                put("title", task.title)
                put("timeLabel", task.timeLabel ?: JSONObject.NULL)
                put("triggerAt", task.triggerAtMillis ?: JSONObject.NULL)
                put("done", task.done)
            })
        }
        prefs.edit().putString(KEY_TASKS, array.toString()).apply()
    }

    companion object {
        const val PREFS_NAME = "bhagya_store"
        private const val KEY_TASKS = "tasks_json"
    }
}
