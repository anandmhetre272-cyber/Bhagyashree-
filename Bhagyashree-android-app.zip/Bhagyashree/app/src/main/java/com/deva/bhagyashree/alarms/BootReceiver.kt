package com.deva.bhagyashree.alarms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.deva.bhagyashree.data.TaskStore

/** Alarms are lost when the phone restarts, so put the pending ones back. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val store = TaskStore(context)
        val scheduler = ReminderScheduler(context)
        store.load()
            .filter { !it.done && it.triggerAtMillis != null }
            .forEach { scheduler.schedule(it) }
    }
}
