package com.deva.bhagyashree.brain

import java.util.Locale

/**
 * The wake word: "Bhagya". Recognition output is never exactly what you said, so we accept the
 * common spellings and both scripts.
 */
object Wake {

    val WORDS = listOf(
        "bhagya", "bhagyashree", "bhagyashri", "bhagya shree", "bhagya shri", "bhagyaa",
        "भाग्या", "भाग्यश्री", "भाग्य"
    )

    /** Text the assistant shows while it waits for the wake word. */
    fun hint(): String = "Bhagya"

    fun contains(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return WORDS.any { lower.contains(it) }
    }

    /** Removes the wake word and anything before it, leaving just the command. */
    fun strip(text: String): String {
        val lower = text.lowercase(Locale.US)
        var cut = -1
        WORDS.forEach { word ->
            val at = lower.indexOf(word)
            if (at >= 0) {
                val end = at + word.length
                if (end > cut) cut = end
            }
        }
        if (cut < 0) return text.trim()
        return text.substring(cut).trim().trimStart(',', '.', '-', '!', '।').trim()
    }
}
