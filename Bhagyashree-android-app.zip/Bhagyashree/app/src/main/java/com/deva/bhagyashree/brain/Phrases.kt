package com.deva.bhagyashree.brain

/**
 * Every sentence Bhagya says, in all three languages. Keeping them in one file means you can
 * fix a wording without touching the logic.
 */
object Phrases {

    fun greeting(language: Language): String = when (language) {
        Language.ENGLISH -> "Hi, I am Bhagya. What is on your mind?"
        Language.HINDI -> "नमस्ते! मैं भाग्या हूँ। बताइए, क्या करना है?"
        Language.MARATHI -> "नमस्कार! मी भाग्या. सांगा, काय करायचं आहे?"
    }

    fun thanks(language: Language): String = when (language) {
        Language.ENGLISH -> "Anytime."
        Language.HINDI -> "कोई बात नहीं।"
        Language.MARATHI -> "काही हरकत नाही."
    }

    fun help(language: Language): String = when (language) {
        Language.ENGLISH ->
            "Here is what I can do. To add something, say add and then the task, like add milk at six pm. " +
                "To hear everything, say my list. To finish an item, say done two. To remove one, say delete two. " +
                "Say plan my day for a routine, or ask me the time or the date. " +
                "You can also start with the wake word, Bhagya."
        Language.HINDI ->
            "मैं ये कर सकती हूँ। काम जोड़ने के लिए कहिए — जोड़ो दूध लाना छह बजे। " +
                "सब सुनने के लिए कहिए — मेरी लिस्ट। काम पूरा करने के लिए कहिए — दो पूरा करो। " +
                "हटाने के लिए कहिए — तीन हटाओ। दिन की योजना के लिए कहिए — दिन की योजना। " +
                "समय और तारीख भी पूछ सकती हैं। शुरू में भाग्या कहिए।"
        Language.MARATHI ->
            "मी हे करू शकते. काम जोडायला सांगा — जोडा दूध आणायचं सहा वाजता. " +
                "सगळं ऐकायला सांगा — माझी यादी. काम पूर्ण करायला सांगा — दोन पूर्ण कर. " +
                "काढायला सांगा — तीन काढा. दिनाची योजना म्हणा. " +
                "वेळ आणि तारीख पण विचारू शकता. सुरुवातीला भाग्या म्हणा."
    }

    fun added(language: Language, title: String, timeLabel: String?): String = when (language) {
        Language.ENGLISH ->
            if (timeLabel == null) "Added $title." else "Added $title, for $timeLabel."
        Language.HINDI ->
            if (timeLabel == null) "ठीक है, $title जोड़ दिया।"
            else "ठीक है, $title जोड़ दिया, $timeLabel के लिए।"
        Language.MARATHI ->
            if (timeLabel == null) "ठीक आहे, $title जोडलं."
            else "ठीक आहे, $title जोडलं, $timeLabel ला."
    }

    fun whatToAdd(language: Language): String = when (language) {
        Language.ENGLISH -> "What should I add?"
        Language.HINDI -> "क्या जोड़ना है?"
        Language.MARATHI -> "काय जोडायचं?"
    }

    fun done(language: Language, title: String): String = when (language) {
        Language.ENGLISH -> "Marked $title as done."
        Language.HINDI -> "$title पूरा हो गया।"
        Language.MARATHI -> "$title पूर्ण झालं."
    }

    fun removed(language: Language, title: String): String = when (language) {
        Language.ENGLISH -> "Removed $title."
        Language.HINDI -> "$title हटा दिया।"
        Language.MARATHI -> "$title काढून टाकलं."
    }

    fun notFound(language: Language, number: String): String = when (language) {
        Language.ENGLISH ->
            "I could not find item $number. Say my list to check the numbers."
        Language.HINDI ->
            "नंबर $number की कोई चीज़ नहीं मिली। मेरी लिस्ट कहिए, नंबर देख लीजिए।"
        Language.MARATHI ->
            "क्रमांक $number चं काही सापडलं नाही. माझी यादी म्हणा, क्रमांक बघा."
    }

    fun cleared(language: Language, count: Int): String = when (language) {
        Language.ENGLISH -> "Cleared $count finished item${if (count == 1) "" else "s"}."
        Language.HINDI -> "$count पूरे हुए काम हटा दिए।"
        Language.MARATHI -> "$count पूर्ण झालेली कामं काढली."
    }

    fun nothingDone(language: Language): String = when (language) {
        Language.ENGLISH -> "Nothing is marked done yet."
        Language.HINDI -> "अभी कोई काम पूरा नहीं हुआ।"
        Language.MARATHI -> "अजून काही पूर्ण झालं नाही."
    }

    fun clock(language: Language, time: String): String = when (language) {
        Language.ENGLISH -> "It is $time."
        Language.HINDI -> "अभी $time बजे हैं।"
        Language.MARATHI -> "आता $time वाजले."
    }

    fun date(language: Language, day: String): String = when (language) {
        Language.ENGLISH -> "Today is $day."
        Language.HINDI -> "आज $day है।"
        Language.MARATHI -> "आज $day आहे."
    }

    fun count(language: Language, open: Int): String = when (language) {
        Language.ENGLISH -> "You have $open open item${if (open == 1) "" else "s"} on your list."
        Language.HINDI -> "लिस्ट में $open काम बाकी हैं।"
        Language.MARATHI -> "यादीत $open कामं बाकी आहेत."
    }

    fun wake(language: Language): String = when (language) {
        Language.ENGLISH -> "Yes, tell me."
        Language.HINDI -> "हाँ, बोलिए।"
        Language.MARATHI -> "हो, सांगा."
    }

    fun fallback(language: Language): String = when (language) {
        Language.ENGLISH ->
            "I am not sure about that one yet. Add an AI key in Settings and I can answer properly, " +
                "or say add, my list, or plan my day."
        Language.HINDI ->
            "ये मुझे अभी समझ नहीं आया। सेटिंग्स में AI की चाबी डालिए, तब मैं पूरा जवाब दे पाऊँगी। " +
                "या कहिए — जोड़ो, मेरी लिस्ट, दिन की योजना।"
        Language.MARATHI ->
            "हे मला अजून समजलं नाही. सेटिंग्जमध्ये AI ची किल्ली टाका, मग मी पूर्ण उत्तर देईन. " +
                "किंवा सांगा — जोडा, माझी यादी, दिनाची योजना."
    }

    fun listeningHint(language: Language): String = when (language) {
        Language.ENGLISH -> "Listening..."
        Language.HINDI -> "सुन रही हूँ..."
        Language.MARATHI -> "ऐकत आहे..."
    }
}
