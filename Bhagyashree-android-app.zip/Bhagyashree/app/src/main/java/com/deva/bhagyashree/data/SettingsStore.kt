package com.deva.bhagyashree.data

import android.content.Context

/**
 * Small user preferences: which language Bhagya should answer in, whether hands free listening is
 * on, and how her voice is tuned. The AI key and the task list live in their own classes.
 */
class SettingsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(TaskStore.PREFS_NAME, Context.MODE_PRIVATE)

    /** "auto" means detect from what the user says, otherwise an en-IN / hi-IN / mr-IN tag. */
    var languageTag: String
        get() = prefs.getString(KEY_LANGUAGE, "auto").orEmpty().ifBlank { "auto" }
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var handsFree: Boolean
        get() = prefs.getBoolean(KEY_HANDS_FREE, false)
        set(value) = prefs.edit().putBoolean(KEY_HANDS_FREE, value).apply()

    var pitch: Float
        get() = prefs.getFloat(KEY_PITCH, 1.22f)
        set(value) = prefs.edit().putFloat(KEY_PITCH, value).apply()

    var rate: Float
        get() = prefs.getFloat(KEY_RATE, 1.02f)
        set(value) = prefs.edit().putFloat(KEY_RATE, value).apply()

    var welcomeShown: Boolean
        get() = prefs.getBoolean(KEY_WELCOME, false)
        set(value) = prefs.edit().putBoolean(KEY_WELCOME, value).apply()

    companion object {
        private const val KEY_LANGUAGE = "language_tag"
        private const val KEY_HANDS_FREE = "hands_free"
        private const val KEY_PITCH = "voice_pitch"
        private const val KEY_RATE = "voice_rate"
        private const val KEY_WELCOME = "welcome_shown"
    }
}
