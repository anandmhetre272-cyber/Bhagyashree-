package com.deva.bhagyashree.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.deva.bhagyashree.ui.theme.Space
import kotlin.random.Random

private class Star(val x: Float, val y: Float, val radius: Float, val alpha: Float, val speed: Float)

/**
 * The living background: a slow grid, two drifting light fields and a field of stars that rise.
 * Cheap to draw - one Canvas, no bitmaps - so it does not eat the battery.
 */
@Composable
fun FuturisticBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "space")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift"
    )
    val breathe by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )

    val stars = remember {
        val random = Random(7)
        List(72) {
            Star(
                x = random.nextFloat(),
                y = random.nextFloat(),
                radius = 0.7f + random.nextFloat() * 1.6f,
                alpha = 0.15f + random.nextFloat() * 0.55f,
                speed = 0.15f + random.nextFloat() * 0.6f
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Space.Deep, Space.Deck, Color(0xFF050C16), Space.Deep)
                )
            )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val step = size.minDimension / 9f
            var x = 0f
            while (x <= size.width) {
                drawLine(Space.Line.copy(alpha = 0.20f), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y <= size.height) {
                drawLine(Space.Line.copy(alpha = 0.14f), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }

            val upper = Offset(size.width * 0.18f, size.height * 0.10f)
            val upperRadius = size.minDimension * 0.85f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Space.Teal.copy(alpha = 0.13f * breathe), Color.Transparent),
                    center = upper,
                    radius = upperRadius
                ),
                radius = upperRadius,
                center = upper
            )

            val lower = Offset(size.width * 0.85f, size.height * 0.72f)
            val lowerRadius = size.minDimension * 0.95f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Space.Violet.copy(alpha = 0.12f * breathe), Color.Transparent),
                    center = lower,
                    radius = lowerRadius
                ),
                radius = lowerRadius,
                center = lower
            )

            stars.forEach { star ->
                val starY = ((star.y - drift * star.speed) % 1f + 1f) % 1f
                drawCircle(
                    color = Color.White.copy(alpha = star.alpha * (0.45f + 0.55f * breathe)),
                    radius = star.radius,
                    center = Offset(star.x * size.width, starY * size.height)
                )
            }
        }
        content()
    }
}
