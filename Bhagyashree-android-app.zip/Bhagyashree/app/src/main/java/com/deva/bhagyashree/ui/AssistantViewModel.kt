package com.deva.bhagyashree.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.deva.bhagyashree.alarms.ReminderScheduler
import com.deva.bhagyashree.brain.Action
import com.deva.bhagyashree.brain.AssistantBrain
import com.deva.bhagyashree.brain.Language
import com.deva.bhagyashree.brain.Phrases
import com.deva.bhagyashree.brain.Wake
import com.deva.bhagyashree.data.SettingsStore
import com.deva.bhagyashree.data.Task
import com.deva.bhagyashree.data.TaskStore
import com.deva.bhagyashree.llm.LlmClient
import com.deva.bhagyashree.voice.Speaker
import com.deva.bhagyashree.voice.VoiceInput
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)

/**
 * Holds the conversation, the task list, the language choice and the wake-word loop.
 * The screen only reads state from here.
 */
class AssistantViewModel(app: Application) : AndroidViewModel(app) {

    private val store = TaskStore(app)
    private val settings = SettingsStore(app)
    private val scheduler = ReminderScheduler(app)
    private val llm = LlmClient(app)
    val speaker = Speaker(app)

    val messages = mutableStateListOf<ChatMessage>()
    val tasks = mutableStateListOf<Task>()

    var listening by mutableStateOf(false)
        private set
    var partialText by mutableStateOf("")
        private set
    var thinking by mutableStateOf(false)
        private set
    var aiConnected by mutableStateOf(false)
        private set

    /** "auto" or a language tag such as "hi-IN". */
    var languageTag by mutableStateOf("auto")
        private set
    var handsFree by mutableStateOf(false)
        private set
    var pitch by mutableStateOf(1.22f)
        private set

    private var nextMessageId = 1L
    private var wakeArmedUntil = 0L
    private var voiceWarningShown = false

    private val voice = VoiceInput(
        context = app,
        onPartial = { partial -> partialText = partial },
        onFinal = { text -> handleSpeech(text) },
        onError = { message ->
            partialText = ""
            addAssistantMessage(message, speakIt = false, language = Language.ENGLISH)
        },
        onListeningChanged = { value -> listening = value }
    )

    init {
        tasks.addAll(store.load())
        aiConnected = llm.hasKey
        languageTag = settings.languageTag
        handsFree = settings.handsFree
        pitch = settings.pitch
        voice.setLanguage(recognitionTag())
        speaker.pitch = pitch
        speaker.rate = settings.rate

        val welcomeLanguage = if (languageTag == "auto") Language.ENGLISH else Language.fromTag(languageTag)
        addAssistantMessage(
            welcome(welcomeLanguage),
            speakIt = false,
            language = welcomeLanguage
        )
    }

    private fun welcome(language: Language): String = when (language) {
        Language.ENGLISH ->
            "Hi, I am Bhagya. Tap the orb and talk to me, or say Bhagya to wake me. " +
                "I understand English, हिंदी and मराठी."
        Language.HINDI ->
            "नमस्ते! मैं भाग्या हूँ। नीचे गोले को दबाइए और बोलिए, या भाग्या कहिए। " +
                "मैं हिंदी, मराठी और अंग्रेज़ी समझती हूँ।"
        Language.MARATHI ->
            "नमस्कार! मी भाग्या. खाली गोल दाबा आणि बोला, किंवा भाग्या म्हणा. " +
                "मला मराठी, हिंदी आणि इंग्रजी समजतं."
    }

    // ---------------------------------------------------------------- conversation

    fun send(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return

        messages.add(ChatMessage(nextMessageId++, input, fromUser = true))

        val forced = if (languageTag == "auto") null else Language.fromTag(languageTag)
        val reply = AssistantBrain.respond(input, tasks.toList(), forcedLanguage = forced)
        applyActions(reply.actions)

        if (reply.needsAi && llm.hasKey) {
            thinking = true
            viewModelScope.launch {
                val answer = llm.ask(input, tasks.toList(), reply.language)
                thinking = false
                addAssistantMessage(answer, speakIt = true, language = reply.language)
            }
        } else {
            addAssistantMessage(reply.text, speakIt = true, language = reply.language)
        }
    }

    /** Speech arrives here. In hands-free mode only the wake word (or an armed follow-up) counts. */
    private fun handleSpeech(text: String) {
        partialText = ""
        val now = System.currentTimeMillis()

        if (!handsFree) {
            send(text)
            return
        }

        if (Wake.contains(text)) {
            val command = Wake.strip(text)
            val language = replyLanguage(text)
            if (command.isBlank()) {
                wakeArmedUntil = now + 9000
                addAssistantMessage(Phrases.wake(language), speakIt = true, language = language)
            } else {
                wakeArmedUntil = 0
                send(command)
            }
            return
        }

        if (now < wakeArmedUntil) {
            wakeArmedUntil = 0
            send(text)
        }
        // Otherwise it was background chatter; stay quiet and keep listening.
    }

    private fun addAssistantMessage(text: String, speakIt: Boolean, language: Language) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        messages.add(ChatMessage(nextMessageId++, clean, fromUser = false))
        if (!speakIt) return

        speaker.speak(clean, language)
        if (language != Language.ENGLISH && !speaker.supports(language) && !voiceWarningShown) {
            voiceWarningShown = true
            val note = when (language) {
                Language.HINDI ->
                    "Tip: install the Hindi voice in Android settings, Text to speech, to hear me in Hindi."
                Language.MARATHI ->
                    "Tip: install the Marathi voice in Android settings, Text to speech, to hear me in Marathi."
                Language.ENGLISH -> ""
            }
            if (note.isNotEmpty()) {
                messages.add(ChatMessage(nextMessageId++, note, fromUser = false))
            }
        }
    }

    private fun replyLanguage(text: String): Language =
        if (languageTag == "auto") Language.detect(text) else Language.fromTag(languageTag)

    private fun recognitionTag(): String =
        if (languageTag == "auto") Language.ENGLISH.tag else languageTag

    // ---------------------------------------------------------------- task actions

    private fun applyActions(actions: List<Action>) {
        if (actions.isEmpty()) return

        actions.forEach { action ->
            when (action) {
                is Action.AddTask -> {
                    val task = Task(
                        id = System.currentTimeMillis(),
                        title = action.title,
                        timeLabel = action.timeLabel,
                        triggerAtMillis = action.triggerAtMillis
                    )
                    tasks.add(task)
                    scheduler.schedule(task)
                }

                is Action.CompleteTask -> {
                    val task = tasks.getOrNull(action.index)
                    if (task != null) {
                        tasks[action.index] = task.copy(done = true)
                        scheduler.cancel(task.id)
                    }
                }

                is Action.DeleteTask -> {
                    val task = tasks.getOrNull(action.index)
                    if (task != null) {
                        tasks.removeAt(action.index)
                        scheduler.cancel(task.id)
                    }
                }

                Action.ClearDone -> {
                    tasks.filter { it.done }.forEach { scheduler.cancel(it.id) }
                    tasks.removeAll { it.done }
                }
            }
        }

        store.save(tasks.toList())
    }

    fun toggleDone(task: Task) {
        val index = tasks.indexOf(task)
        if (index < 0) return
        val updated = task.copy(done = !task.done)
        tasks[index] = updated
        if (updated.done) scheduler.cancel(updated.id) else scheduler.schedule(updated)
        store.save(tasks.toList())
    }

    // ---------------------------------------------------------------- voice

    fun startListening() {
        partialText = ""
        speaker.stop()
        voice.start(continuousMode = handsFree)
    }

    fun stopListening() {
        voice.stop()
    }

    fun onMicPermissionDenied() {
        addAssistantMessage(
            "I need microphone access to listen. You can still type below.",
            speakIt = false,
            language = Language.ENGLISH
        )
    }

    fun setHandsFree(enabled: Boolean) {
        handsFree = enabled
        settings.handsFree = enabled
        if (enabled) {
            val note = "Hands free is on. Say Bhagya, then your command. Keep the app open; " +
                "always-on listening in the background needs more setup."
            addAssistantMessage(note, speakIt = false, language = Language.ENGLISH)
            startListening()
        } else {
            voice.stop()
        }
    }

    fun setLanguage(tag: String) {
        languageTag = tag
        settings.languageTag = tag
        voice.setLanguage(recognitionTag())
        val language = if (tag == "auto") Language.ENGLISH else Language.fromTag(tag)
        addAssistantMessage(
            when (language) {
                Language.ENGLISH -> "Okay, I will answer in English."
                Language.HINDI -> "ठीक है, मैं हिंदी में जवाब दूँगी।"
                Language.MARATHI -> "ठीक आहे, मी मराठीत उत्तर देईन."
            },
            speakIt = false,
            language = language
        )
    }

    fun setPitch(value: Float) {
        pitch = value
        settings.pitch = value
        speaker.applyVoiceSettings(value, settings.rate)
    }

    // ---------------------------------------------------------------- settings

    fun apiKey(): String = llm.apiKey()

    fun model(): String = llm.model()

    fun baseUrl(): String = llm.baseUrl()

    fun saveAiSettings(apiKey: String, model: String, baseUrl: String) {
        llm.saveSettings(apiKey, model, baseUrl)
        aiConnected = llm.hasKey
        addAssistantMessage(
            if (aiConnected) "AI is connected. Ask me anything now."
            else "AI key cleared. I will stick to the offline commands.",
            speakIt = false,
            language = Language.ENGLISH
        )
    }

    override fun onCleared() {
        voice.destroy()
        speaker.shutdown()
        super.onCleared()
    }
}
