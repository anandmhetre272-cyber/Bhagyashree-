package com.deva.bhagyashree.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Wraps SpeechRecognizer.
 *
 * Two modes:
 *  - one shot: listen, hand over the text, stop.
 *  - continuous (hands free): listen, hand over the text, immediately listen again. Used for the
 *    "Bhagya" wake word. Speech recognition is not built for always-on listening, so this is a
 *    loop of short listens with a small gap; keep the app open while it runs.
 */
class VoiceInput(
    private val context: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onListeningChanged: (Boolean) -> Unit
) {

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val restartTask = Runnable { startInternal() }

    var languageTag: String = "en-IN"
        private set
    private var continuous = false

    fun setLanguage(tag: String) {
        if (tag == languageTag) return
        languageTag = tag
        // The recognizer keeps the language of the intent it was started with, so rebuild it.
        if (continuous) {
            recognizer?.cancel()
            scheduleRestart(120)
        }
    }

    fun start(continuousMode: Boolean = false) {
        continuous = continuousMode
        startInternal()
    }

    fun stop() {
        continuous = false
        handler.removeCallbacks(restartTask)
        recognizer?.stopListening()
        onListeningChanged(false)
    }

    fun destroy() {
        continuous = false
        handler.removeCallbacks(restartTask)
        recognizer?.destroy()
        recognizer = null
    }

    private fun startInternal() {
        handler.removeCallbacks(restartTask)
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition is not available on this phone. You can type instead.")
            continuous = false
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
                it.setRecognitionListener(listener)
            }
        }
        onListeningChanged(true)
        try {
            recognizer?.startListening(buildIntent())
        } catch (e: Exception) {
            onListeningChanged(false)
            scheduleRestart(600)
        }
    }

    private fun buildIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
    }

    private fun scheduleRestart(delayMillis: Long) {
        if (!continuous) return
        handler.removeCallbacks(restartTask)
        handler.postDelayed(restartTask, delayMillis)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = onListeningChanged(true)
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = onListeningChanged(false)

        override fun onError(error: Int) {
            onListeningChanged(false)
            val quiet = error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                error == SpeechRecognizer.ERROR_CLIENT ||
                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY

            if (continuous && quiet) {
                // Nobody spoke, or the engine timed out. Just listen again, silently.
                scheduleRestart(350)
                return
            }
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ||
                error == SpeechRecognizer.ERROR_NETWORK ||
                error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT
            ) {
                continuous = false
            }
            onError(messageFor(error))
            scheduleRestart(700)
        }

        override fun onResults(results: Bundle?) {
            onListeningChanged(false)
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
            if (text.isNullOrEmpty()) {
                if (continuous) scheduleRestart(300) else onError("I didn't catch that. Try again.")
            } else {
                onFinal(text)
                scheduleRestart(400)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.let(onPartial)
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun messageFor(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed to listen."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech needs a network connection right now. You can type instead."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Still listening, give me a second."
        SpeechRecognizer.ERROR_AUDIO -> "I could not hear the microphone. Check that nothing is covering it."
        else -> "Voice input failed. You can type instead."
    }
}
