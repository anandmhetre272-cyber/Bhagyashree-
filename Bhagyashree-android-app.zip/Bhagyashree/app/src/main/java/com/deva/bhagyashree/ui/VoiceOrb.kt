package com.deva.bhagyashree.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.deva.bhagyashree.ui.theme.Space

/**
 * The core orb: pulsing rings when idle, faster and brighter while listening.
 */
@Composable
fun VoiceOrb(
    listening: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 96.dp
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val beat by transition.animateFloat(
        initialValue = 0.93f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(1150, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beat"
    )
    val ring by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(if (listening) 1500 else 2800, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "ring"
    )

    Box(
        modifier = modifier
            .size(size)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val base = this.size.minDimension / 2f
            val scale = if (listening) beat else 1f

            repeat(3) { index ->
                val t = ((ring + index / 3f) % 1f)
                drawCircle(
                    color = Space.Teal.copy(alpha = (1f - t) * if (listening) 0.45f else 0.25f),
                    radius = base * (0.58f + t * 0.85f),
                    style = Stroke(width = 2f)
                )
            }

            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Space.Cyan, Space.Teal, Color(0xFF0C3B33)),
                    center = center,
                    radius = base * 0.75f
                ),
                radius = base * 0.60f * scale
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.22f),
                radius = base * 0.60f * scale,
                style = Stroke(width = 2f)
            )
        }
        Icon(
            imageVector = if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
            contentDescription = if (listening) "Stop listening" else "Speak",
            tint = Color(0xFF04121A),
            modifier = Modifier.size(size / 3.4f)
        )
    }
}
