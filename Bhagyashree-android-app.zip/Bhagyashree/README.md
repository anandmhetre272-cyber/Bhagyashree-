# Bhagya — a voice-first assistant with a live civilisation deck

**App name:** Bhagyashree · **Wake word:** “Bhagya” · **Voice:** a teenage Indian girl
**Understands and answers in:** English, हिंदी, मराठी

Bhagya is a complete Android app (Kotlin + Jetpack Compose) you open in Android Studio, build and
run on your own phone. You talk, she talks back, and she runs your day: tasks, timed reminders,
a spoken plan, and — if you add a key — general answers.

Everything except the general answers works **offline**: no account, no server, no key.

---

## 1. The look: a live civilisation deck

The interior is built to feel like the interface of an advanced civilisation, not a form:

- **Deep-space deck** — navy-to-black gradient, a slow moving star field and a faint tech grid,
  drawn on one `Canvas` so it stays cheap on the battery.
- **Breathing light fields** — teal and violet glows that slowly pulse behind everything.
- **The core orb** — three expanding holographic rings around a glowing core. Idle it breathes;
  while listening it beats faster and brighter; tap it to stop.
- **Holographic panels** — chat replies sit in translucent bordered panes (violet for her, teal
  for you), tasks in glowing pills, the header a spaced-out “BHAGYASHREE” with a status dot:
  `NEURAL CORE ONLINE` / `LISTENING` / `THINKING`.

Tune the palette in one place: `ui/theme/Theme.kt` (object `Space`).

---

## 2. What she can do

| You say (any of the three languages) | What happens |
| --- | --- |
| “add task pay the electricity bill at 6 pm” · “जोड़ो दूध लाना छह बजे” · “जोडा दूध आणायचं सहा वाजता” | Adds it and books a reminder |
| “remind me to call amma tomorrow at 9” | Adds it with a reminder |
| “what’s on my list” · “मेरी लिस्ट” · “माझी यादी” | Reads every item, numbered, with time and status |
| “done two” · “दो पूरा करो” · “दोन पूर्ण कर” | Marks item 2 finished, cancels its alarm |
| “delete three” · “तीन हटाओ” · “तीन काढा” | Removes item 3 |
| “clear done” · “पूरे हुए हटाओ” · “पूर्ण झालेले काढा” | Removes finished items |
| “plan my day” · “दिन की योजना” · “दिनाची योजना” | Speaks a plan from your items plus suggested blocks |
| “what’s the time” · “कितने बजे” · “किती वाजले” | Answers |
| “what’s the date” · “आज की तारीख” · “आजची तारीख” | Answers |
| “help” · “मदद” · “मदत” | Explains what she can do |
| anything else | Answered by AI, if a key is set |

**Times she understands:** `at 7`, `at 7:30 pm`, `tomorrow at 9`, `in 20 minutes`, `tonight`,
`छह बजे`, `सुबह 7 बजे`, `उद्या सकाळी 8 वाजता`, `सहा वाजता`. A bare “at 7” or “7 बजे” is treated as
evening, which is what people usually mean; a part-of-day word (“सुबह”, “सकाळ”, “रात”) overrides it.

**Spoken numbers work** (“done two”, “दो पूरा करो”, “दोन पूर्ण कर”) because that is how speech
recognition transcribes you.

---

## 3. The wake word: “Bhagya”

Tap the **Wake word off** pill at the bottom to turn hands free on. Then:

1. Say **“Bhagya”** → she answers “हाँ, बोलिए” / “हो, सांगा” / “Yes, tell me” and stays armed for
   about nine seconds, so your next sentence is treated as the command.
2. Or say it in one breath: **“Bhagya, add milk at six”**, **“भाग्या, दूध जोड़ो”**.

She accepts the usual mis-hearings and both scripts: `bhagya`, `bhagyashree`, `भाग्या`, `भाग्यश्री`.

**Be clear about what this is.** This is hands-free listening **while the app is open**, implemented
as a loop of short `SpeechRecognizer` sessions. That is the honest, battery-sane way to do it
without a paid wake-word SDK: Android has no built-in always-on keyword detection, and a
background listener built on `SpeechRecognizer` gets killed, drops after silence, and drains
battery. For a true “works with the screen off” wake word you need an on-device keyword engine
(Picovoice Porcupine is the common choice) or a foreground service with a persistent notification.
Section 8 explains how to go there.

---

## 4. Her voice: a teenage Indian girl

- Pitch defaults to **1.22** and rate to **1.02** — brighter and a little quicker than neutral.
- Settings (gear icon) has a **pitch slider**: 1.20–1.30 is the teenage range; 1.4+ sounds cartoonish.
- She speaks with the **en-IN / hi-IN / mr-IN** voice, whichever matches the reply.

The timbre itself comes from the phone's text-to-speech engine, so install the voice data first:

`Settings → System → Languages & input → Text-to-speech output → (your engine, usually Google)
→ Install voice data → Hindi / Marathi`

If a Hindi or Marathi voice is missing, she still replies in that language on screen and says so
with a one-time tip in the chat.

---

## 5. Language: how it picks one

- **Auto** (default) — recognises with `en-IN` (best for English and Hinglish) and detects the
  reply language from what you actually said: Devanagari script plus marker words decide Hindi vs
  Marathi; romanised input is scored the same way.
- **English / हिंदी / मराठी** — pins both recognition and replies to that language. Pick मराठी and
  the recogniser listens in Marathi, so “उद्या सकाळी आठ वाजता” lands correctly.

With an AI key, the answer is requested in the detected language too.

---

## 6. Run it

**Android Studio:** unzip → `File > Open` → pick the `Bhagyashree` folder (the one with
`settings.gradle.kts`) → let Gradle sync (JDK 17 if asked) → pick your phone → Run.

**Terminal:**

```bash
./gradlew assembleDebug     # build
./gradlew installDebug      # install on the connected phone
./gradlew test              # unit tests for the offline brain (English, Hindi, Marathi)
```

Requirements: Android Studio Ladybug or newer (older versions will offer to upgrade the project),
a phone on Android 7.0+ with Google speech recognition, and nothing else — the Gradle wrapper is
included.

**First run asks for:** microphone (for listening) and notifications (for reminders). Deny
notifications and tasks still save, but reminders stay silent.

---

## 7. Connecting an AI (optional)

Gear icon → paste an **API key**, **model** and **base URL** → Save. Any OpenAI-compatible service:

| Service | Base URL | Model example |
| --- | --- | --- |
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` |
| Groq | `https://api.groq.com/openai/v1` | `llama-3.3-70b-versatile` |
| OpenRouter | `https://openrouter.ai/api/v1` | `openai/gpt-4o-mini` |
| Local (LM Studio, Ollama) | `http://<your-pc-ip>:1234/v1` | whatever you loaded |

The key stays in the app's private storage on the phone and is only sent to the service you chose.
For a local `http://` server, add `android:usesCleartextTraffic="true"` to `<application>` in
`AndroidManifest.xml` while testing, and remove it before sharing the APK. If you ever publish this
app, move the AI call behind your own backend.

---

## 8. Where everything lives

```
Bhagyashree/
├─ settings.gradle.kts, build.gradle.kts, gradle.properties    project + plugin versions
├─ gradlew, gradlew.bat, gradle/wrapper/                        Gradle wrapper (included)
└─ app/src/
   ├─ main/AndroidManifest.xml                                  permissions, receivers, launcher
   ├─ main/res/                                                 theme, strings, icons
   ├─ main/java/com/deva/bhagyashree/
   │  ├─ MainActivity.kt                                        entry point, permissions
   │  ├─ ui/HomeScreen.kt                                       the deck: header, chips, chat, orb
   │  ├─ ui/FuturisticBackground.kt                             stars, grid, breathing light fields
   │  ├─ ui/VoiceOrb.kt                                         the pulsing core orb
   │  ├─ ui/AssistantViewModel.kt                               state + wake-word loop + wiring
   │  ├─ ui/theme/Theme.kt                                      the palette (object Space)
   │  ├─ brain/AssistantBrain.kt                                rules in 3 languages → replies + actions
   │  ├─ brain/Language.kt                                      the 3 languages + detection
   │  ├─ brain/Phrases.kt                                       every sentence she says, 3 languages
   │  ├─ brain/Wake.kt                                          wake word matching + stripping
   │  ├─ brain/TimeParser.kt                                    “छह बजे”, “at 6 pm” → a timestamp
   │  ├─ brain/RoutinePlanner.kt                                list summary + day plan, 3 languages
   │  ├─ voice/VoiceInput.kt                                    recogniser wrapper + hands-free loop
   │  ├─ voice/Speaker.kt                                       TTS wrapper, teen pitch, per-language
   │  ├─ data/Task.kt, data/TaskStore.kt, data/SettingsStore.kt  model + persistence + preferences
   │  ├─ llm/LlmClient.kt                                       optional AI answers
   │  └─ alarms/…                                               alarms, notifications, re-arm on boot
   └─ test/java/com/deva/bhagyashree/brain/AssistantBrainTest.kt  unit tests
```

Design rule: **the brain is plain Kotlin with no Android imports**, so it is testable without a
phone. `AssistantViewModel` is the only place that joins brain → storage → alarms → voice → screen.

---

## 9. Extending her

**A new command.** Add a branch in `AssistantBrain.respond()`; if it changes data, add a case to the
`Action` sealed interface and handle it in `AssistantViewModel.applyActions()`. Add a test — the
suite runs in milliseconds.

**A new sentence.** Everything spoken lives in `Phrases.kt` and `RoutinePlanner.kt`, one `when` per
language. No logic to touch.

**Recurring routines** (“every day at 7 am, gym”). Add a `repeat` field to `Task`, then reschedule
the next occurrence inside `ReminderReceiver` after it fires. This is the single most useful upgrade
for a routine app.

**A real always-on wake word.** Two routes:
1. *Foreground service* — a service with `foregroundServiceType="microphone"`, a persistent
   notification, and the same `VoiceInput` loop. Needs `FOREGROUND_SERVICE` +
   `FOREGROUND_SERVICE_MICROPHONE` permissions on Android 14+, and users must start it from the app.
2. *Porcupine (recommended)* — train a custom “Bhagya” keyword in the Picovoice console, drop the
   `.ppn` in `assets/`, and run it in a service. Far lower battery, works with the screen off, no
   network. This is what you want for a phone in a pocket.

**Another language.** Add an entry to `Language`, its sentences to `Phrases.kt`, and its command
keywords to `AssistantBrain`. Past three or four languages, the keyword approach stops scaling and
you should route everything through the AI path with the offline rules as a fallback.

**Real database.** `TaskStore` keeps the list as one JSON string. Swap in Room when you outgrow it;
nothing outside `TaskStore` changes.

---

## 10. If something goes wrong

| Symptom | Fix |
| --- | --- |
| Sync fails: “Unsupported class file major version” | Wrong JDK. `Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK` → JDK 17. |
| She hears nothing | Microphone permission; Google app installed (it provides recognition); hands-free mode keeps the app in front. |
| “Speech needs a network connection” | The offline speech pack is not downloaded — connect once, or type. |
| She answers in the wrong language | Pin the language with the chip (Auto → English/हिंदी/मराठी). Marathi and Hindi are close in script. |
| Hindi or Marathi reply has no sound | Install the voice data (section 4). She shows a tip the first time. |
| Voice sounds like a man or an adult | It is the phone's engine. Try a different TTS engine, or nudge pitch to 1.28–1.32. |
| Wake word ignores you | Speak within ~2 m, keep the app open, and turn hands-free on. Recognition drops after long silence — it restarts itself, but the first syllable after a gap can be lost. |
| Reminders a few minutes late | Exact alarms need permission on Android 12+; she falls back to inexact rather than nagging. Grant “Alarms & reminders” for exact timing. |
| “done two” does nothing | Ask “what’s on my list” first — commands use those numbers. |

---

## 11. Honest limits

- **Wake word scope:** in-app, hands free, app must be open. A true screen-off wake word needs
  Porcupine or a foreground service (section 9) — not a hack, a different architecture.
- **Speech recognition is the phone's**, not hers. Hinglish (“kal 6 baje milk lana”) is the hardest
  case: the recogniser may transcribe it in one script, so pin a language if it keeps missing.
- **The offline brain is rule based.** Fast and predictable, but it only knows the commands above;
  anything else needs the AI path.
- **Her voice is the phone's TTS** with pitch and rate tuned. To make it genuinely hers you would
  record or synthesise a custom voice and ship it as a TTS engine or audio clips — a different
  project, and a licensing question if you clone a real person's voice.
- **The day plan is a sensible template**, not a personalised optimiser.
- **Not Play-Store ready:** no signing config, no adaptive icon set for every density, no privacy
  policy. All easy to add when you want to publish.
